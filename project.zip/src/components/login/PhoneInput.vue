<template>
  <div class="form--group">
    <label for="phone" class="form--label">شماره همراه</label>
    <input
      type="text"
      id="phone"
      class="form--input"
      :class="{ 'form--input--error': error }"
      placeholder="مثلا ۰۹۱۲۳۴۵۶۷۸۹"
      v-model="internalPhone"
    />
    <span v-if="error" class="form--error">{{ error }}</span>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  phoneNumber: String,
  error: String,
})

const emit = defineEmits(['update:phoneNumber'])

const internalPhone = ref(props.phoneNumber)

watch(internalPhone, (val) => {
  emit('update:phoneNumber', val)
})

watch(
  () => props.phoneNumber,
  (val) => {
    internalPhone.value = val
  },
)
</script>

<style lang="scss">
.form {
  &--group {
    display: flex;
    flex-direction: column;
  }
  &--label {
    font-size: 16px;
    color: #3c4351;
    padding: 8px;
  }
  &--input {
    background-color: #f9fafb;
    padding: 8px;
    width: 100%;
    height: 48px;
    border: none;
    border-radius: 6px;
    font-family: 'IranSansNum';
  }
  &--input::placeholder {
    font-size: 14px;
    color: #c3c5c9;
    margin: 8px;
  }
  &--input--error {
    border: 1px solid red;
  }
  &--error {
    color: red;
    font-size: 12px;
    margin-top: 4px;
  }
}
</style>
