<template>
  <button type="submit" class="form--btn" :disabled="loading">
    <span v-if="loading" class="spinner"></span>
    <span v-else>ورود</span>
  </button>
</template>

<script setup>
defineProps({
  loading: {
    type: Boolean,
    default: false,
  },
})
</script>

<style lang="scss">
.form {
  &--btn {
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    height: 48px;
    margin-top: 20px;
    border: none;
    border-radius: 8px;
    padding: 8px 16px;
    background-color: #4152a0;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: background-color 0.3s;

    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  }

  .spinner {
    width: 18px;
    height: 18px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
