<template>
  <div v-if="show" class="overlay">
    <div class="loader-wrapper">
      <div class="loader">
        <span class="part part1"></span>
        <span class="part part2"></span>
        <span class="part part3"></span>
      </div>
      <div class="loader-text">
        <span
          v-for="(word, index) in words"
          :key="index"
          :style="{ animationDelay: `${index * 0.25}s` }"
        >
          {{ word }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  show: Boolean,
})

const words = ['Part', 'Software', 'Group']
</script>

<style scoped>
.overlay {
  position: fixed;
  inset: 0;
  background: #ffffff;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  direction: ltr;
}

.loader-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.loader {
  display: flex;
  gap: 12px;
}

.part {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background-color: #4152a0;
  animation: wave 1s ease-in-out infinite;
}

.part1 {
  animation-delay: 0s;
}
.part2 {
  animation-delay: 0.2s;
}
.part3 {
  animation-delay: 0.4s;
}

@keyframes wave {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-15px);
  }
}

.loader-text {
  display: flex;
  gap: 8px;
  font-family: 'Peyda', sans-serif;
  font-size: 24px;
  font-weight: bold;
  color: #4152a0;
}

.loader-text span {
  opacity: 0;
  transform: translateY(10px);
  display: inline-block;
  animation: fadeUp 0.6s forwards;
}

@keyframes fadeUp {
  0% {
    opacity: 0;
    transform: translateY(10px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
