<template>
  <div
    class="sidebar-item"
    :class="{ active: isActive }"
    role="button"
    :aria-pressed="isActive ? 'true' : 'false'"
    @click="() => clicked()"
  >
    <component v-if="iconComponent" :is="iconComponent" class="icon-wrapper" aria-hidden="true" />
    <span v-else-if="iconSvg" class="icon-wrapper" aria-hidden="true" v-html="iconSvg"></span>
    <span v-else class="icon-wrapper" aria-hidden="true">
      <slot name="icon"></slot>
    </span>
    <span class="label">{{ label }}</span>
  </div>
</template>

<script setup>
defineProps({
  iconComponent: { type: [Object, Function], default: null },
  iconSvg: { type: String, default: '' },
  label: { type: String, required: true },
  isActive: { type: Boolean, default: false },
  clicked: { type: Function },
})
</script>

<style lang="scss" scoped>
.sidebar-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  font-size: 14px;
  color: $secondary-color;
  cursor: pointer;
  border-radius: 8px;
  transition: all 0.18s ease-in-out;
  user-select: none;

  .icon-wrapper {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    flex: 0 0 18px;
    line-height: 0;

    .selectedSVG {
      color: $primary-color;
    }

    svg {
      width: 100%;
      height: 100%;
      display: block;
      fill: currentColor;
      stroke: currentColor;
    }
  }

  .label {
    display: inline-block;
    vertical-align: middle;
  }

  &:hover {
    color: #5171ff;
  }

  &.active {
    color: $primary-color;
    font-weight: 600;
  }
}
</style>
