<template>
  <div v-if="showModal" class="modal-overlay">
    <div class="modal-content">
      <slot />
    </div>
  </div>
</template>

<script setup>
import { showModal } from '@/stores/dashboardStore'
</script>

<style scoped lang="scss">
.modal-overlay {
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.85);
  //   backdrop-filter: blur(1px);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 20;
  pointer-events: auto;
}

.modal-content {
  border-radius: 12px;
  padding: 40px 32px;
  width: 440px;
  max-width: 90%;
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 16px;
  align-items: center;
}
</style>
