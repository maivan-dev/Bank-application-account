<template>
  <div class="dashboard-card dashboard-card--bank">
    <div class="dashboard-card__header">
      <span class="dashboard-card__title">موجودی کل</span>
      <span class="dashboard-card__menu" @click="toggleMenu">⋮</span>
    </div>
    <div class="dashboard-card__balance">
      <span>{{ moneySeperateDigits(balance) }}</span>
    </div>
    <div class="dashboard-card__iban">
      <span>{{ brakingCardNumber(cardNumber)[0] }}</span>
      <span>{{ brakingCardNumber(cardNumber)[1] }}</span>
      <span>{{ brakingCardNumber(cardNumber)[2] }}</span>
      <span>{{ brakingCardNumber(cardNumber)[3] }}</span>
    </div>
    <DropdownComponent v-model:open="open" :options="options" />
  </div>
  <ToastNotif :message="toastMessage" :visible="visible" :type="toastType" />
</template>

<script setup>
import DropdownComponent from '@/components/DropdownComponent.vue'
import DeleteAccount from '@/assets/images/delete-account.svg'
import EditAccount from '@/assets/images/edit-account.svg'
import ToastNotif from '@/components/toast/ToastNotif.vue'
import { deleteAccount } from '@/services/axios/data'
import { balance, cardNumber, deleteAccountStatus } from '@/stores/dashboardStore'
import { brakingCardNumber, moneySeperateDigits } from '@/utilities/numberFunctions'
import { ref } from 'vue'

const open = ref(false)

const toastMessage = ref('')
const visible = ref(false)
const toastType = ref('success')

const options = [
  {
    label: 'تغییر حساب متصل',
    icon: EditAccount,
    active: false,
    color: '#C3C5C9',
  },
  {
    label: 'حذف حساب بانکی',
    icon: DeleteAccount,
    onClick: async () => {
      visible.value = false

      const res = await deleteAccount()
      try {
        visible.value = true
        if (res.status === 204) {
          toastMessage.value = 'حساب شما با موفقیت حذف شد.'
          toastType.value = 'success'
          deleteAccountStatus.value = true
        } else {
          toastMessage.value = 'خطا در حذف حساب ، دوباره تلاش کنید.'
          toastType.value = 'error'
        }
      } catch {
        toastMessage.value = 'خطا در حذف حساب ، دوباره تلاش کنید.'
        toastType.value = 'error'
      }
    },
    active: !deleteAccountStatus.value,
    color: 'red',
  },
]

const toggleMenu = () => (open.value = !open.value)
</script>

<style lang="scss" scoped>
.dashboard-card {
  box-sizing: border-box;
  border-radius: 12px;
  padding: 36px;
  color: #fff;
  background-image:
    url('/src/assets/images/noise.png'), linear-gradient(90deg, #4152a0, #d0c9c1, #d0c9c1);
  background-repeat: repeat, no-repeat;
  background-blend-mode: overlay;
  background-size:
    50px 50px,
    cover;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  direction: ltr;
  position: relative;

  &__menu {
    font-size: 24px;
    cursor: pointer;
  }
  &__header {
    display: flex;
    justify-content: space-between;
    margin: 0;
    padding: 0;
  }

  &__balance {
    font-size: 40px;
    font-weight: 700;
    display: flex;
    align-items: start;
  }

  &__iban {
    font-size: 18px;
    letter-spacing: 2px;
    display: flex;
    justify-content: space-between;
    font-weight: 400;
    font-style: normal;
    font-size: 32px;
    margin-top: auto;
    line-height: 100%;
  }

  &--bank {
    width: 456px;
    height: 260px;
    display: flex;
    flex-direction: column;
  }
}
</style>
