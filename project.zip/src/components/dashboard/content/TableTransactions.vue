<template>
  <div class="transactions">
    <div class="transactions__topbar">
      <h2 class="transactions__title">
        لیست تراکنش‌ها <span class="transactions__currency">(ریال)</span>
      </h2>

      <div class="container">
        <div class="transactions__filter">
          <div class="transactions__sort">
            <SortIcon />
            <span>مرتب‌سازی: </span>
          </div>
          <select v-model="type" class="transactions__filter-select">
            <option value="">همه</option>
            <option value="deposit">واریز</option>
            <option value="withdraw">برداشت</option>
          </select>
        </div>

        <div class="transactions__controls">
          <div class="transactions__search">
            <input type="text" class="transactions__search-input" placeholder="جستجو" />
            <SearchIcon />
          </div>
        </div>
      </div>
    </div>

    <!-- Table Section -->
    <table v-if="transactions?.length" class="transactions__table">
      <thead class="transactions__header">
        <th class="transactions__header-cell">مبلغ تراکنش</th>
        <th class="transactions__header-cell">تاریخ و ساعت تراکنش</th>
        <th class="transactions__header-cell">نوع تراکنش</th>
      </thead>

      <tbody>
        <tr v-for="(item, index) in transactions" :key="index" class="transactions__row">
          <td class="transactions__cell">{{ moneySeperateDigits(item.amount) }}</td>
          <td class="transactions__cell">
            {{ formatDate(item.date) }}
          </td>
          <td class="transactions__cell transactions__cell--type">
            <span class="transactions__status">
              <DepositIcon v-if="item.type === 'deposit'" />
              <WithdrawIcon v-if="item.type === 'withdraw'" />
              {{ item.type === 'deposit' ? 'واریز' : 'برداشت' }}
            </span>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Pagination -->
    <div v-if="transactions?.length" class="transactions__pagination">
      <button @click="prev" :disabled="currentStart === 1" class="transactions__page-btn">
        &lt;
      </button>
      <button
        v-for="p in visiblePages"
        @click="() => (page = p)"
        :key="p"
        :class="['transactions__page-btn', { 'transactions__page-btn--active': page === p }]"
      >
        {{ p }}
      </button>

      <button @click="next" :disabled="currentStart === totalPages" class="transactions__page-btn">
        &gt;
      </button>
    </div>
  </div>
</template>

<script setup>
import DepositIcon from '@/assets/images/deposit-icon.svg'
import SearchIcon from '@/assets/images/search.svg'
import SortIcon from '@/assets/images/sort.svg'
import WithdrawIcon from '@/assets/images/withdraw.svg'
import { totalPages } from '@/stores/dashboardStore'
import { page, transactions, type } from '@/stores/tableStore'
import { moneySeperateDigits } from '@/utilities/numberFunctions'
import { computed, ref, watch } from 'vue'

const currentStart = ref(1)

watch(
  () => page,
  (newPage) => {
    if (newPage === 1) {
      currentStart.value = 1
    }
  },
  { immediate: true },
)

const formatDate = (dateStr) => {
  const date = new Date(dateStr)
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  return `${year}-${month}-${day} ، ${hours}:${minutes}`
}

const visiblePages = computed(() => {
  const pages = []
  for (let i = 0; i < 4; i++) {
    const mPage = currentStart.value + i
    if (mPage <= totalPages.value) {
      pages.push(mPage)
    }
  }
  return pages
})

const next = () => {
  if (currentStart.value + 4 <= totalPages.value) {
    currentStart.value++
  }
}

const prev = () => {
  if (currentStart.value > 1) {
    currentStart.value--
  }
}
</script>

<style lang="scss" scoped>
.transactions {
  width: 1164px;
  max-width: 100%;
  height: 520px;
  padding: 24px 24px 14px;
  border-radius: 12px;
  background: #fff;
  display: flex;
  flex-direction: column;
  gap: 24px;
  box-sizing: border-box;

  .container {
    display: flex;
    gap: 16px;
  }

  &__topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  &__title {
    font-size: 18px;
    font-weight: 700;
    color: #3c4351;

    .transactions__currency {
      font-size: 14px;
      font-weight: 400;
      color: #8999b9;
    }
  }

  &__controls {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  &__search {
    width: 257px;
    display: flex;
    gap: 4px;
    border: 1px solid #e0e6f0;
    border-radius: 8px;
    font-size: 14px;
    align-items: center;

    &-input {
      width: 220px;
      height: 32px;
      border: none;
      padding-right: 8px;

      &:focus {
        border-color: #4152a0;
      }
    }
  }

  &__filter {
    display: flex;
    gap: 8px;
    &-select {
      height: 36px;
      width: 183px;
      padding: 0 8px;
      border: 1px solid #e0e6f0;
      border-radius: 8px;
      font-size: 14px;
      outline: none;
      cursor: pointer;
      font-family: 'peyda';

      &:focus {
        border-color: #4152a0;
      }
    }
  }

  &__sort {
    display: flex;
    align-items: center;
    gap: 4px;
    border: none;
    background: transparent;
    color: #4152a0;
    font-size: 14px;
    cursor: pointer;
  }

  &__table {
    width: 100%;
    display: flex;
    flex-direction: column;
    direction: ltr;
  }

  &__header {
    display: flex;
    background: #4152a0;
    border-radius: 8px;
    color: #fff;

    &-cell {
      flex: 1;
      box-sizing: border-box;
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
    }
  }

  &__row {
    display: flex;
    border-bottom: 1px solid #f0f0f0;

    &:nth-child(even) {
      background: #f9f9fb;
    }
  }

  &__cell {
    flex: 1;
    box-sizing: border-box;
    height: 61px;
    padding: 10px;
    display: flex;
    align-items: center;
    justify-content: center;

    &--type {
      font-weight: 600;
    }
  }

  &__status {
    display: flex;
    gap: 4px;
    color: #3c4351;
  }

  &__pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    margin-top: auto;
  }

  &__page-btn {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: #fff;
    border: none;
    cursor: pointer;

    &--active {
      background: #4152a0;
      color: #fff;
      border-color: #4152a0;
    }
  }
}
</style>
