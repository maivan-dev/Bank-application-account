<template>
  <div class="dashboard-card dashboard-card--installment">
    <div class="dashboard-card__header">
      <span class="dashboard-card__title">{{ title }}</span>
      <slot name="topLeftSection"></slot>
    </div>
    <slot name="content"></slot>
    <button class="dashboard-card__button"><slot name="buttonContent"></slot></button>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    default: '',
  },
})
</script>

<style lang="scss" scoped>
.dashboard-card {
  box-sizing: border-box;
  border-radius: 12px;
  padding: 24px;
  background: #fff;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
  justify-content: space-between;

  &__header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
  }

  // &__details {
  //   font-size: 14px;
  //   line-height: 1.6;

  //   span {
  //     font-weight: 600;
  //   }
  // }

  &__button {
    margin-top: auto;
    padding: 12px 20px;
    border: none;
    border-radius: 8px;
    background: #f1f3f9;
    cursor: pointer;
    font-size: 16px;
    font-weight: 700;
    line-height: 28px;
    color: #3c4351;

    &:hover {
      background: #e2e6f3;
    }
  }

  &--installment {
    width: 338px;
    height: 260px;
  }
}
</style>
