<template>
  <div class="container">
    <span class="container__price">
      <div class="currency">ریال</div>
      <span>{{ moneySeperateDigits(pointsVal) ?? 0 }}</span>
    </span>
    <span class="container__deadline">{{ deadlineVal ?? 0 }} <span>ماهه</span></span>
  </div>
</template>

<script setup>
import { deadlineVal, pointsVal } from '@/stores/dashboardStore'
import { moneySeperateDigits } from '@/utilities/numberFunctions'
</script>

<style lang="scss" scoped>
.container {
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-top: auto;
  align-items: center;

  &__price {
    color: #4152a0;
    font-size: 40px;
    font-weight: 700;
    display: flex;
    gap: 4px;
    direction: ltr;
    align-items: center;

    div {
      font-size: 14px;
      font-weight: 400;
      color: #8999b9;
    }
  }
  .currency {
    direction: rtl;
    display: inline-block;
  }

  &__deadline {
    color: #4152a0;
    font-size: 18px;
    font-weight: 700;

    span {
      font-size: 14px;
      font-weight: 400;
      color: #8999b9;
    }
  }
}
</style>
