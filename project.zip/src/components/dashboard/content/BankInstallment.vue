<template>
  <table class="table">
    <tr>
      <td class="table__title">مبلغ قسط :</td>
      <td class="table__value">
        <span>
          <div class="currency">ریال</div>
          <span> {{ moneySeperateDigits(installmentMoney ?? '') }}</span>
        </span>
      </td>
    </tr>
    <tr>
      <td class="table__title">تاریخ سررسید :</td>
      <td class="table__value">
        {{ dateSeperated(installmentDate) ? dateSeperated(installmentDate) : '-' }}
      </td>
    </tr>
  </table>
</template>

<script setup>
import { installmentDate, installmentMoney } from '@/stores/dashboardStore'
import { dateSeperated, moneySeperateDigits } from '@/utilities/numberFunctions'
</script>

<style lang="scss" scoped>
.table {
  width: 100%;
  display: flex;
  flex-direction: column;
  margin-top: auto;
  gap: 12px;

  tr {
    width: 100%;
    display: flex;
    justify-content: space-between;
  }

  &__title {
    font-size: 14px;
    font-weight: 400;
    color: #8999b9;
  }
  &__value {
    font-size: 14px;
    font-weight: 600;
    color: #3c4351;
    direction: ltr;
  }
}

.currency {
  direction: rtl;
  display: inline-block;
}
</style>
