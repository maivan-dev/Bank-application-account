<template>
  <main>
    <div class="container">
      <HeaderBase />
      <div class="base-card">
        <h2 class="title">{{ title }}</h2>
        <div class="title-line"></div>
        <div class="content">
          <slot />
        </div>
        <div class="actions">
          <slot name="actions" />
        </div>
      </div>
    </div>
  </main>
</template>

<script setup>
import HeaderBase from '../header/HeaderBase.vue'

defineProps({
  title: {
    type: String,
    required: true,
  },
})
</script>

<style scoped lang="scss">
.container {
  display: flex;
  flex-direction: column;
  max-width: 100vw;
  min-height: 100vh;
  overflow-x: hidden;
  background: #f7f8fa;
  margin: 0;
}
.base-card {
  font-family: 'peyda';
  width: 1400px;
  min-height: 542px;
  background: #fff;
  border-radius: 12px;
  padding: 40px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-sizing: border-box;
  margin: 42px auto;
}

.title {
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  color: #3c4351;
  margin: 0;
}

.title-line {
  width: 100%;
  height: 1px;
  background: #e2edff;
  margin: 16px 0 32px;
}

.content {
  flex: 1;
}

.actions {
  display: flex;
  justify-content: flex-end;
  gap: 16px;
}
</style>
