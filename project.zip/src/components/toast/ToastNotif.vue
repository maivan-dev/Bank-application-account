<template>
  <div
    v-if="visible && active"
    :class="['toast', `toast--${position}`]"
    :style="{ backgroundColor: bg, color: text }"
  >
    <span v-html="icon" style="margin-left: 8px"></span>
    {{ message }}
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  visible: { type: Boolean, default: false },
  message: { type: String, default: '' },
  position: { type: String, default: 'bottom-right' },
  duration: { type: Number, default: 3000 },
  bgColor: { type: String, default: null },
  textColor: { type: String, default: null },
  type: { type: String, default: 'info' },
})

const active = ref(false)

const emit = defineEmits(['update:visible'])
const timeoutId = ref(null)

const bg = computed(() => {
  if (props.bgColor) return props.bgColor
  switch (props.type) {
    case 'success':
      return '#4CAF50'
    case 'error':
      return '#f44336'
    case 'warning':
      return '#ff9800'
    case 'info':
      return '#2196F3'
    default:
      return '#4152a0'
  }
})

const text = computed(() => {
  return props.textColor || '#fff'
})

const icon = computed(() => {
  switch (props.type) {
    case 'success':
      return '✅'
    case 'error':
      return '❌'
    case 'warning':
      return '⚠️'
    case 'info':
      return 'ℹ️'
    default:
      return ''
  }
})

watch(
  () => props.visible,
  (newVal) => {
    if (timeoutId.value) clearTimeout(timeoutId.value)
    if (newVal) {
      active.value = true
      timeoutId.value = setTimeout(() => {
        emit('update:visible', false)
        timeoutId.value = null
        active.value = false
      }, props.duration)
    }
  },
)
</script>

<style lang="scss">
.toast {
  position: fixed;
  padding: 12px 24px;
  border-radius: 8px;
  font-size: 14px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  z-index: 9999;
  max-width: 300px;
  text-align: center;
  transition:
    opacity 0.3s ease,
    transform 0.3s ease;

  &--top-left {
    top: 20px;
    left: 20px;
  }
  &--top-right {
    top: 20px;
    right: 20px;
  }
  &--top-center {
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
  }
  &--bottom-left {
    bottom: 20px;
    left: 20px;
  }
  &--bottom-right {
    bottom: 20px;
    right: 20px;
  }
  &--bottom-center {
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
  }
}
</style>
