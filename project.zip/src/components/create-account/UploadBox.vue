<template>
  <label class="upload-box">
    <div class="content">
      <img v-if="previewImage" :src="previewImage" alt="preview" class="preview-img" />

      <template v-else>
        <div class="icon">
          <slot name="icon">
            <Svgupload />
          </slot>
        </div>
        <p class="text">
          تصویر را بکشید و اینجا رها کنید <br />
          یا <span class="click-text">کلیک کنید.</span>
        </p>
      </template>
    </div>

    <input type="file" class="file-input" accept="image/*" @change="handleFileChange" />

    <div class="footer-text">
      {{ label }}
    </div>
  </label>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import Svgupload from '@/assets/images/upload.svg'

const props = defineProps({
  label: {
    type: String,
    required: true,
  },
  imageName: {
    type: String,
  },
})

const previewImage = ref(null)

const handleFileChange = (event) => {
  const file = event.target.files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = (e) => {
      const base64 = reader.result
      localStorage.setItem(props.imageName, base64)
      previewImage.value = e.target.result
    }
    reader.readAsDataURL(file)
  }
}

onMounted(() => {
  if (props.imageName) {
    const storedImage = localStorage.getItem(props.imageName)
    if (storedImage) {
      previewImage.value = storedImage
    }
  }
})
</script>

<style scoped>
.upload-box {
  width: 320px;
  height: 232px;
  background: #fafbfc;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  cursor: pointer;
}

.content {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2px dashed #ddd4d0;
  border-radius: 12px 12px 0 0;
  text-align: center;
  transition: all 0.2s ease-in-out;
  overflow: hidden;
}

.content:hover {
  border-color: #4152a0;
}

.icon {
  color: #98a2b3;
}

.text {
  font-size: 14px;
  color: #6b7280;
}

.click-text {
  color: #4152a0;
  font-weight: 600;
}

.file-input {
  position: absolute;
  inset: 0;
  opacity: 0;
  cursor: pointer;
}

.footer-text {
  padding: 16px 12px;
  font-size: 14px;
  color: #3c4351;
  text-align: start;
  border: none;
}

.preview-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
