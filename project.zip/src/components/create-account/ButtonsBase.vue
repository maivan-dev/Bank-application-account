<template>
  <button
    @click="handleClick"
    class="btn"
    :class="[`btn--${variant}`]"
    :style="{
      backgroundColor: bgColor,
      color: textColor,
      margin: margin,
    }"
  >
    {{ label }}
  </button>
</template>

<script setup>
const props = defineProps({
  label: {
    type: String,
    required: true,
  },
  textColor: {
    type: String,
    default: '#FFFFFF',
  },
  bgColor: {
    type: String,
    default: '#3B5998',
  },
  variant: {
    type: String,
    default: 'primary',
    validator: (value) => ['primary', 'secondary', 'outline'].includes(value),
  },
  margin: {
    type: String,
    default: '0px',
  },
  clicked: {
    type: Function,
  },
})

function handleClick() {
  if (props.clicked) {
    props.clicked()
  }
}
</script>

<style lang="scss" scoped>
.btn {
  @include btn-shape;

  &--primary {
    background-color: #3b5998;
    color: #fff;

    &:hover {
      opacity: 0.9;
    }
  }

  &--secondary {
    background-color: #f4f6fa;
    color: #1f1f1f;

    &:hover {
      background-color: #e0e3e8;
    }
  }

  &--outline {
    background-color: transparent;
    border: 1px solid #3b5998;
    color: #3b5998;

    &:hover {
      background-color: rgba(59, 89, 152, 0.1);
    }
  }
}
</style>
