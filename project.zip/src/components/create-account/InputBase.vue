<template>
  <div class="base-input">
    <label v-if="label">{{ label }}</label>
    <input
      :type="type"
      :placeholder="placeholder"
      v-model="localValue"
      :style="{ height, width }"
      :class="{ 'input--error': error }"
    />
    <span v-if="error" class="input--error-message">{{ error }}</span>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  modelValue: String,
  label: String,
  placeholder: String,
  type: {
    type: String,
    default: 'text',
  },
  height: {
    type: String,
    default: '48px',
  },
  width: {
    type: String,
    default: '100%',
  },
  error: {
    type: String,
  },
})

const emit = defineEmits(['update:modelValue'])

const localValue = ref(props.modelValue)

watch(
  () => props.modelValue,
  (newVal) => {
    localValue.value = newVal
  },
  { immediate: true },
)

watch(
  localValue,
  (newVal) => {
    emit('update:modelValue', newVal)
  },
  { immediate: true },
)
</script>

<style lang="scss" scoped>
@import '../../assets/styles/abstracts/variables';
@import '../../assets/styles/abstracts/mixins';

.base-input {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;

  label {
    font-size: 14px;
    font-weight: 600;
    color: $secondary-color;
  }

  input {
    @include input-style;
    box-sizing: border-box;
  }

  .input--error {
    border: 1px solid red;
  }
  .input--error-message {
    color: red;
    font-size: 12px;
    margin-top: 4px;
  }
}
</style>
