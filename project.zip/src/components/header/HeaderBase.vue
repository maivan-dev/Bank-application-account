<script setup lang="ts">
import { getUserData } from '@/services/auth/info'
</script>

<template>
  <header class="menu">
    <div class="menu-rightside">
      <img src="../../assets/images/header/merAt-logo.svg" alt="" />
    </div>
    <div class="menu-leftside">
      <div class="menu-leftside-bill">
        <img src="../../assets/images/header/bill.svg" alt="" />
      </div>
      <div class="menu-leftside-user-pic">
        <img src="../../assets/images/header/userPic.svg" alt="" />
      </div>
      <div class="menu-leftside-number">
        <span>{{ getUserData().phoneNumber }}</span>
      </div>
    </div>
  </header>
</template>

<style lang="scss" scoped>

.menu {
  height: 68px;
  max-width: 100vw;
  background: #ffffff;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 14px 40px;
  flex-shrink: 0;
  &-rightside {
    width: 178px;
    height: 31px;
    img {
      object-fit: cover;
      width: 100%;
      height: 100%;
    }
  }
  &-leftside {
    display: flex;
    flex-direction: row;
    align-items: center;

    &-bill {
      width: 18px;
      height: 22px;
      margin-left: 15px;
      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
      }
    }
    &-user-pic {
      width: 41px;
      height: 41px;
      margin-left: 8px;
      img {
        object-fit: cover;
        width: 100%;
        height: 100%;
      }
    }
    &-number {
      color: #3c4351;
      font-size: 14px;
    }
  }
}
</style>
