<template>
  <transition name="fade">
    <div v-if="mOpen" class="dropdown-menu">
      <div
        v-for="(option, idx) in options"
        :key="idx"
        class="dropdown-item"
        :class="{ itemDisable: !option.active }"
        @click="handleOption(option)"
      >
        <component :is="option.icon" v-if="option.icon" />
        <span :style="{ color: option.color }" class="dropdown-label">{{ option.label }}</span>
      </div>
    </div>
  </transition>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  options: { type: Array, required: true },
  open: { type: Boolean, default: false },
})

const emit = defineEmits(['update:open'])
const mOpen = ref(props.open)

watch(
  () => props.open,
  () => {
    mOpen.value = props.open
  },
)

const handleOption = (option) => {
  option.onClick && option.onClick()
  if (option.active) emit('update:open', false)
}
</script>

<style scoped>
.dropdown-menu {
  width: 187px;
  min-height: 88px;
  background: #fff;
  border-radius: 12px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.15);
  z-index: 9999;
  font-family: inherit;
  position: absolute;
  top: 74px;
  right: 36px;
}

.dropdown-item {
  width: 100%;
  min-height: 32px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #333;
  cursor: pointer;
  padding: 4px 8px;
  border-radius: 8px;
  transition:
    background 0.2s,
    color 0.2s;
}

.itemDisable {
  color: #c3c5c9;
  background: #f9f9f9;
  cursor: not-allowed;
}

.dropdown-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
}

.dropdown-label {
  flex: 1;
  text-align: right;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
