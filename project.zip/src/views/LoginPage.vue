<template>
  <div class="container">
    <div class="login--box">
      <div class="login--form">
        <div class="login--form--logo">
          <img src="../assets/images/logo-login.svg" alt="logo" />
        </div>

        <div class="login--form--origin">
          <form @submit.prevent="handleLogin" id="loginForm" class="form">
            <PhoneInput v-model:phoneNumber="phoneNumber" :error="errors?.phoneNumber" />
            <PasswordInput v-model:password="password" :error="errors?.password" />
            <LoginButton :loading="loading" />
          </form>
        </div>

        <div class="login--form--span">
          <span>پشتیبانی : </span>
          <span>12345678-021</span>
        </div>
      </div>

      <div class="login--img">
        <div class="login--img--bac"></div>
      </div>
    </div>
  </div>
  <ToastNotif :message="toastMessage" :visible="visible" :type="toastType" />
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import PhoneInput from '@/components/login/PhoneInput.vue'
import PasswordInput from '@/components/login/PasswordInput.vue'
import LoginButton from '@/components/login/LoginButton.vue'
import { login } from '@/services/axios/authService'
import { setLoginToken } from '@/services/auth/token'
import { validateLogin } from '@/services/validations/loginValidation'
import { setUserData } from '@/services/auth/info'
import ToastNotif from '@/components/toast/ToastNotif.vue'

const router = useRouter()

const phoneNumber = ref('')
const password = ref('')
const errors = reactive({})
const toastMessage = ref('')
const visible = ref(false)
const toastType = ref('success')
const loading = ref(false)

const handleLogin = async () => {
  const { isValid, errors: validationErrors } = validateLogin({
    phoneNumber: phoneNumber.value,
    password: password.value,
  })

  errors.phoneNumber = validationErrors.phoneNumber
  errors.password = validationErrors.password

  if (!isValid) {
    return
  }

  visible.value = false
  try {
    loading.value = true
    const res = await login(phoneNumber.value, password.value)
    if (res.status === 200) {
      const data = res.data.data
      toastMessage.value = 'لاگین موفق بود.'
      setLoginToken(data?.token, data?.expiresIn)
      setUserData(data?.user?.firstName, data?.user?.lastName, data?.user?.phoneNumber)
      visible.value = true
      toastType.value = 'success'
      setTimeout(() => {
        router.replace('/dashboard')
      }, 2000)
    }
    return
  } catch (err) {
    toastMessage.value = err?.response?.data?.error?.message?.fa || 'لاگین ناموفق بود.'
    visible.value = true
    toastType.value = 'error'
  } finally {
    loading.value = false
  }
}
</script>

<style lang="scss">
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
body {
  margin: 0 auto;
  width: 100%;
  height: 100vh;
  background-image: url('../assets/images/BG-login.png');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}
.container {
  max-width: 1920px;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login {
  &--box {
    background-color: #ffffff;
    min-width: 1200px;
    height: 840px;
    margin: 120px 360px;
    display: flex;
    box-shadow: 0px 0px 4px 0px #0043650d;
  }

  &--form {
    position: relative;
    height: 100%;
    width: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;

    &--logo {
      margin-top: 83px;
      width: 300px;
      height: 100px;
      img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
    }

    &--span {
      position: absolute;
      bottom: 35px;
      font-size: 14px;
    }
  }

  &--img {
    background-color: #ffffff;
    width: 50%;
    height: 100%;
    padding: 20px;
    &--bac {
      width: 100%;
      height: 100%;
      background-image: url('../assets/images/login-pic.png');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      border-radius: 12px;
    }
  }
}
.form {
  width: 354px;
  height: 280px;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  gap: 12px;
  margin-top: 83px;

  &--input--error {
    border: 1px solid red;
  }
  &--error {
    color: red;
    font-size: 12px;
    margin-top: 4px;
  }
}
</style>
