<script setup>
import { reactive, ref, watch } from 'vue'

import BaseCard from '../components/slot/BaseCard.vue'
import InputBase from '@/components/create-account/InputBase.vue'
import ButtonsBase from '@/components/create-account/ButtonsBase.vue'
import { useRouter } from 'vue-router'
import { validatePersonalInfo } from '@/services/validations/personalInfoValidation'

const router = useRouter()

const firstName = ref(localStorage.getItem('firstName') || '')
const lastName = ref(localStorage.getItem('lastName') || '')
const postalCode = ref(localStorage.getItem('postalCode') || '')
const address = ref(localStorage.getItem('address') || '')

const errors = reactive({})

watch(firstName, (val) => localStorage.setItem('firstName', val))
watch(lastName, (val) => localStorage.setItem('lastName', val))
watch(postalCode, (val) => localStorage.setItem('postalCode', val))
watch(address, (val) => localStorage.setItem('address', val))

function NextStep() {
  const { isValid, errors: validationErrors } = validatePersonalInfo({
    firstName: firstName.value,
    lastName: lastName.value,
    postalCode: postalCode.value,
    address: address.value,
  })

  errors.firstName = validationErrors.firstName
  errors.lastName = validationErrors.lastName
  errors.postalCode = validationErrors.postalCode
  errors.address = validationErrors.address

  if (!isValid) {
    return
  }

  localStorage.setItem('firstName', firstName.value)
  localStorage.setItem('lastName', lastName.value)
  localStorage.setItem('postalCode', postalCode.value)
  localStorage.setItem('address', address.value)

  router.push('/create-account/national-card')
}

function PreviousStep() {
  router.push('/dashboard')
}
</script>

<template>
  <BaseCard title="اطلاعات فردی">
    <div class="form-container">
      <div class="form-grid">
        <InputBase
          label="نام"
          v-model="firstName"
          placeholder="نام فارسی"
          :error="errors.firstName"
        />
        <InputBase
          label="نام خانوادگی"
          v-model="lastName"
          placeholder="نام خانوادگی کامل"
          :error="errors.lastName"
        />
        <InputBase
          label="کد پستی"
          v-model="postalCode"
          placeholder="۹۱۷۵۶۸۷۴۲۳"
          :error="errors.postalCode"
        />
      </div>
      <InputBase
        label="محل سکونت"
        v-model="address"
        placeholder="بولوار ملک آباد ، خیام جنوبی ۱۳ ، گلایل ۱۰ ، پلاک۱۲۳ ، واحد۱"
        :height="'120px'"
        width="100%"
        :error="errors.address"
      />
    </div>

    <template #actions>
      <ButtonsBase :clicked="PreviousStep" label="قبلی" bgColor="#ECEEF6" textColor="#000000" />
      <ButtonsBase :clicked="NextStep" label="ثبت و ادامه" bgColor="#4152A0" textColor="#ffffff" />
    </template>
  </BaseCard>
</template>

<style scoped>
.form-container {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.form-grid {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 24px;
}
</style>
