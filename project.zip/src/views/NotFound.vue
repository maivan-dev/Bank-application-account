<template>
  <div class="not-found">
    <h1>404</h1>
    <p>صفحه مورد نظر پیدا نشد.</p>
    <router-link to="/">بازگشت به خانه</router-link>
  </div>
</template>

<script setup></script>

<style scoped lang="scss">
.not-found {
  text-align: center;
  margin-top: 100px;

  h1 {
    font-size: 100px;
    color: #1d3e9d;
  }

  p {
    font-size: 20px;
    margin-bottom: 20px;
  }

  a {
    color: white;
    background: #1d3e9d;
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
  }
}
</style>
