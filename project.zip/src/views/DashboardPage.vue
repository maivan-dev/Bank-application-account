<template>
  <HeaderBase />
  <div class="dashboard__box">
    <SidebarDashboard :fullName="fullName" :nationalId="nationalId" />

    <main class="dashboard__content">
      <section class="dashboard__content__cards">
        <BankCard />
        <InstallmentCard title="امتیاز حساب">
          <template #topLeftSection>
            <InfoIcon />
          </template>
          <template #content>
            <AccountPoints />
          </template>
          <template #buttonContent> محاسبه امتیاز </template>
        </InstallmentCard>
        <InstallmentCard title="قسط پیش رو">
          <template #topLeftSection>
            <div style="display: flex; gap: 8px; color: #8999b9; align-items: center">
              <span style="cursor: pointer">جزئیات</span>
              <ChevronLeftIcon />
            </div>
          </template>
          <template #content>
            <BankInstallment />
          </template>
          <template #buttonContent>
            <div style="display: flex; align-items: center; gap: 4px; justify-content: center">
              <span>پرداخت</span>
              <ArrowLeftIcon />
            </div>
          </template>
        </InstallmentCard>
      </section>

      <TableTransactions />
      <BaseModal>
        <ModalIcon />
        <p style="font-size: 16px; color: #2d2d2d">
          برای دسترسی به داشبورد، لطفاً ابتدا افتتاح حساب کنید
        </p>
        <RouterLink
          to="/create-account/personal-info"
          style="
            background: #2f4eb4;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
            width: 200px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
          "
        >
          افتتاح حساب
        </RouterLink>
      </BaseModal>
    </main>
  </div>
</template>

<script setup>
import SidebarDashboard from '@/components/dashboard/sidebar/SidebarDashboard.vue'
import BankCard from '@/components/dashboard/content/BankCard.vue'
import InstallmentCard from '@/components/dashboard/content/InstallmentCard.vue'
import InfoIcon from '@/assets/images/info.svg'
import ChevronLeftIcon from '@/assets/images/chevron-left.svg'
import ArrowLeftIcon from '@/assets/images/arrow-left.svg'
import BankInstallment from '@/components/dashboard/content/BankInstallment.vue'
import AccountPoints from '@/components/dashboard/content/AccountPoints.vue'

import { onMounted, watch } from 'vue'
import TableTransactions from '@/components/dashboard/content/TableTransactions.vue'
import { getTransactions, getUserInfo } from '@/services/axios/data'
import BaseModal from '@/components/dashboard/content/BaseModal.vue'
import ModalIcon from '@/assets/images/modal.svg'
import { getUserData } from '@/services/auth/info'
import HeaderBase from '@/components/header/HeaderBase.vue'
import { page, transactions, type } from '@/stores/tableStore'
import {
  balance,
  cardNumber,
  deadlineVal,
  deleteAccountStatus,
  fullName,
  installmentDate,
  installmentMoney,
  nationalId,
  pointsVal,
  showModal,
  totalPages,
} from '@/stores/dashboardStore'

const requestForTransactions = async (selectedType, page) => {
  if (!showModal.value) {
    try {
      const response = await getTransactions(selectedType, page)
      if (response.status === 200) {
        transactions.value = response?.data?.data
        totalPages.value = response?.data?.meta?.totalPages
      }
    } catch (err) {
      console.log(err)
    }
  }
}

onMounted(async () => {
  try {
    const response = await getUserInfo()
    if (response.status === 200 && response?.data?.data?.length) {
      const personInfo = response?.data?.data?.[0]
      balance.value = String(personInfo?.balance)
      cardNumber.value = String(personInfo?.cardNumber)
      pointsVal.value = String(personInfo?.score?.amount)
      deadlineVal.value = String(personInfo?.score?.paymentPeriod)
      installmentMoney.value = String(personInfo?.upcomingInstalment?.amount)
      installmentDate.value = personInfo?.upcomingInstalment?.dueDate

      showModal.value = false
      await requestForTransactions(type.value, page.value)
    }
  } catch (err) {
    console.log(err)
  }
})

watch(page, async (newPage) => {
  await requestForTransactions(type.value, newPage)
})

watch(deleteAccountStatus, async () => {
  transactions.value = []
  showModal.value = true
  fullName.value = getUserData()?.firstName + ' ' + getUserData()?.lastName
  nationalId.value = '0747896354'
  balance.value = ''
  cardNumber.value = ''
  pointsVal.value = ''
  deadlineVal.value = ''
  installmentMoney.value = ''
  installmentDate.value = ''
})

watch(type, async (newType) => {
  page.value = 1
  await requestForTransactions(newType, page.value)
})
</script>

<style lang="scss" scoped>
.dashboard {
  &__box {
    display: flex;
    justify-content: center;
    gap: 8px;
    padding-top: 40px;
    min-height: 972px;
    background: $DashboardBackground;
    font-family: 'peyda';
    max-width: 100vw;
  }

  &__content {
    width: 1164px;
    position: relative;

    &__header {
      margin-bottom: 20px;

      h1 {
        font-size: 22px;
        font-weight: bold;
        margin: 0;
      }
    }

    &__cards {
      display: flex;
      justify-content: space-between;
      gap: 24px;
      margin-bottom: 24px;
    }
  }
}
</style>
