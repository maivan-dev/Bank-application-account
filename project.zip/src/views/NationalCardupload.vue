<script setup>
import BaseCard from '../components/slot/BaseCard.vue'
import ButtonsBase from '@/components/create-account/ButtonsBase.vue'
import UploadBox from '@/components/create-account/UploadBox.vue'
import { useRouter } from 'vue-router'

const router = useRouter()

function PreviousStep() {
  router.replace('/create-account/personal-info')
}
function NextStep() {
  router.replace('/create-account/confirm-information')
}
</script>

<template>
  <BaseCard title="تصویر کارت ملی ">
    <div class="upload-container">
      <UploadBox label="تصویر روی کارت ملی" imageName="nationalCard" />
      <UploadBox label="تصویر پشت کارت ملی" imageName="backNationalCard" />
    </div>

    <template #actions>
      <ButtonsBase
        :clicked="() => PreviousStep()"
        label="قبلی"
        bgColor="#ECEEF6"
        textColor="#000000"
      />
      <ButtonsBase
        :clicked="() => NextStep()"
        label="ثبت و ادامه"
        bgColor="#4152A0"
        textColor="#ffffff"
      />
    </template>
  </BaseCard>
</template>

<style scoped>
.upload-container {
  display: flex;
  gap: 24px;
  justify-content: center;
}
</style>
