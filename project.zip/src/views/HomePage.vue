<template>
  <div class="routes-page">
    <h1 class="title">صفحات برنامه</h1>
    <div class="links-grid">
      <router-link to="/" class="card">خانه</router-link>
      <router-link to="/login" class="card">ورود</router-link>
      <router-link to="/dashboard" class="card">داشبورد</router-link>
      <router-link to="/create-account/confirm-information" class="card">تایید اطلاعات</router-link>
      <router-link to="/create-account/personal-info" class="card">اطلاعات شخصی</router-link>
      <router-link to="/create-account/national-card" class="card">کارت ملی</router-link>
      <router-link to="/not-found" class="card">صفحه 404</router-link>
    </div>

    <router-view />
  </div>
</template>

<script setup></script>

<style scoped>
.routes-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #e0e7ff, #f9fafb);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 40px 20px;
}

.title {
  font-size: 28px;
  font-weight: 800;
  color: #1e293b;
  margin-bottom: 32px;
  text-align: center;
}

.links-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
  width: 100%;
  max-width: 900px;
  margin-bottom: 40px;
}

.card {
  background: #fff;
  border-radius: 12px;
  padding: 20px;
  text-align: center;
  font-size: 16px;
  font-weight: 600;
  color: #4152a0;
  text-decoration: none;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
}

.card:hover {
  background: #4152a0;
  color: #fff;
  transform: translateY(-4px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.card.router-link-exact-active {
  background: #ff9800;
  color: #fff;
}
</style>
