<script setup>
import ButtonsBase from '@/components/create-account/ButtonsBase.vue'
import BaseCard from '@/components/slot/BaseCard.vue'
import ToastNotif from '@/components/toast/ToastNotif.vue'
import { createAccount } from '@/services/axios/data'
import { base64ToFile } from '@/services/file'
import { ref } from 'vue'
import { useRouter } from 'vue-router'
const user = {
  firstName: localStorage.getItem('firstName'),
  lastName: localStorage.getItem('lastName'),
  postalCode: localStorage.getItem('postalCode'),
  address: localStorage.getItem('address'),
}

const router = useRouter()

const toastMessage = ref('')
const visible = ref(false)
const toastType = ref('success')

function PreviousStep() {
  router.replace('/create-account/national-card')
}
async function NextStep() {
  visible.value = false
  const cardImage = base64ToFile(
    localStorage.getItem('nationalCard'),
    'nationalCard.png',
    'image/png',
  )
  const firstName = localStorage.getItem('firstName')
  const lastName = localStorage.getItem('lastName')
  const postalCode = localStorage.getItem('postalCode')
  const address = localStorage.getItem('address')

  const formData = new FormData()

  if (cardImage) formData.append('nationalCardImage', cardImage)

  formData.append('firstName', firstName || '')
  formData.append('lastName', lastName || '')
  formData.append('postalCode', postalCode || '')
  formData.append('address', address || '')

  const res = await createAccount(formData)
  if (res.status !== 201) {
    toastMessage.value = 'خطایی در فرآیند افتتاح حساب رخ داده است. مجددا تلاش کنید.'
    toastType.value = 'error'
    visible.value = true
  } else {
    localStorage.removeItem('firstName')
    localStorage.removeItem('lastName')
    localStorage.removeItem('postalCode')
    localStorage.removeItem('address')
    localStorage.removeItem('nationalCard')
    localStorage.removeItem('backNationalCard')

    router.push('/dashboard')
  }
}
</script>

<template>
  <BaseCard title="تایید اطلاعات">
    <div class="information">
      <div class="info-card">
        <div class="info-card__row">
          <div class="info-card__item">
            <span class="info-card__label">نام:</span>
            <span class="info-card__value">{{ user.firstName }}</span>
          </div>
          <div class="info-card__item">
            <span class="info-card__label">نام خانوادگی:</span>
            <span class="info-card__value">{{ user.lastName }}</span>
          </div>
          <div class="info-card__item">
            <span class="info-card__label">کد پستی:</span>
            <span class="info-card__value">{{ user.postalCode }}</span>
          </div>
        </div>

        <div class="info-card__row info-card__row--full">
          <div class="info-card__item">
            <span class="info-card__label">محل سکونت:</span>
            <span class="info-card__value">{{ user.address }}</span>
          </div>
        </div>
      </div>
    </div>

    <template #actions>
      <ButtonsBase
        :clicked="() => PreviousStep()"
        label="قبلی"
        bgColor="#ECEEF6"
        textColor="#000000"
      />
      <ButtonsBase
        :clicked="() => NextStep()"
        label="افتتاح حساب"
        bgColor="#4152A0"
        textColor="#ffffff"
      />
    </template>
  </BaseCard>
  <ToastNotif :message="toastMessage" :type="toastType" :visible="visible" />
</template>

<style scoped lang="scss">
@import '../assets/styles/abstracts/mixins';

.information {
  width: 1320px;
  height: 297px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.info-card {
  width: 100%;
  height: 136px;
  max-width: 1320px;
  background: #fff;

  &__row {
    @include flex-row(space-between, flex-start, 24px);
    margin-bottom: 40px;
    width: 690px;

    &--full {
      flex-direction: column;
      align-items: flex-start;
    }
  }

  &__item {
    @include flex-row(flex-start, baseline, 4px);
    flex: 1;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
  }

  &__label {
    color: #8999b9;
    font-size: 16px;
    margin-bottom: 4px;
  }

  &__value {
    font-size: 16px;
    color: #3c4351;
    font-weight: 600;
  }
}
</style>
