import { getUserData } from '@/services/auth/info'
import { ref } from 'vue'

const userInfo = getUserData()
export const fullName = ref(userInfo?.firstName + ' ' + userInfo?.lastName)
export const nationalId = ref('0747896354')

export const balance = ref('')
export const cardNumber = ref('')
export const pointsVal = ref('')
export const deadlineVal = ref('')
export const installmentMoney = ref('')
export const installmentDate = ref('-')
export const showModal = ref(true)

export const totalPages = ref(0)
export const deleteAccountStatus = ref(false)
