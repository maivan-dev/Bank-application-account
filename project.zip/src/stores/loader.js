import { ref } from 'vue'

export const loading = ref(false)
