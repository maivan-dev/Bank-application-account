import { ref } from 'vue'

export const page = ref(1)
export const type = ref('')
export const transactions = ref([])
