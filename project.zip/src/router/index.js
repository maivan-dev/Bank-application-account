import { createRouter, createWebHistory } from 'vue-router'
import NotFound from '@/views/NotFound.vue'
import { checkLogin } from '@/services/axios/authService'
import { getLoginToken } from '@/services/auth/token'
import { loading } from '@/stores/loader'
import { checkStep } from '@/utilities/createAccount'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('../views/HomePage.vue'),
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../views/LoginPage.vue'),
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: () => import('../views/DashboardPage.vue'),
    },
    {
      path: '/create-account/confirm-information',
      name: 'create',
      component: () => import('../views/CreateAccoutePage.vue'),
    },
    {
      path: '/create-account/personal-info',
      name: 'PersonalInformation',
      component: () => import('../views/PersonalInformation.vue'),
    },
    {
      path: '/create-account/national-card',
      name: 'NationalCard',
      component: () => import('../views/NationalCardupload.vue'),
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: NotFound,
    },
  ],
})
router.beforeEach(async (to) => {
  loading.value = true

  if (to.name === 'dashboard') {
    const isLogin = getLoginToken()
    if (!isLogin) {
      return { name: 'login' }
    }
  } else if (
    to.name === 'PersonalInformation' ||
    to.name === 'NationalCard' ||
    to.name === 'create'
  ) {
    try {
      const res = await checkLogin()
      if (res.status !== 200) {
        return { name: 'login' }
      } else if (res.data.data.length) {
        if (to.name !== 'dashboard') {
          return { name: 'dashboard' }
        }
      } else {
        const step = checkStep()
        if (step === 1 && to.name !== 'PersonalInformation') {
          return { name: 'PersonalInformation' }
        } else if (step === 2 && to.name === 'create') {
          return { name: 'NationalCard' }
        } else if (
          step === 3 &&
          to.name !== 'PersonalInformation' &&
          to.name !== 'NationalCard' &&
          to.name !== 'create'
        ) {
          return { name: 'create' }
        }
      }
    } catch (err) {
      console.log(err)
      if (to.name !== 'login') {
        return { name: 'login' }
      }
    }
  }

  return
})

router.afterEach(() => {
  setTimeout(() => {
    loading.value = false
  }, 1000)
})

export default router
