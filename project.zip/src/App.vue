<script setup>
import { RouterView } from 'vue-router'
import LoaderComponent from './components/LoaderComponent.vue'
import { loading } from './stores/loader';
</script>

<template>
  <LoaderComponent :show="loading" />
  <RouterView />
</template>

<style lang="scss"></style>
\
