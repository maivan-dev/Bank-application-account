export function validateLogin({ phoneNumber, password }) {
  const errors = {}

  if (!phoneNumber) {
    errors.phoneNumber = 'شماره موبایل الزامی است.'
  } else if (!/^09\d{9}$/.test(phoneNumber)) {
    errors.phoneNumber = 'شماره موبایل معتبر نیست.'
  }
  const regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/

  if (!password) {
    errors.password = 'رمز عبور الزامی است.'
  } else if (!regex.test(password)) {
    errors.password = 'رمز عبور باید حداقل ۶ کاراکتر و شامل اعداد و حروف انگلیسی باشد.'
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  }
}
