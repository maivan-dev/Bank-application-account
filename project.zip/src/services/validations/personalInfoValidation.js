// src/services/validations/accountValidation.js
export function validatePersonalInfo({ firstName, lastName, postalCode, address }) {
  const errors = {};

  if (!firstName) {
    errors.firstName = 'نام الزامی است.';
  } else if (firstName.length < 3) {
    errors.firstName = 'نام باید حداقل 3 کاراکتر باشد.';
  } else if (!/^[\u0600-\u06FF\s]+$/.test(firstName)) {
    errors.firstName = 'نام باید فقط شامل حروف فارسی باشد.';
  }

  if (!lastName) {
    errors.lastName = 'نام خانوادگی الزامی است.';
  } else if (lastName.length < 3) {
    errors.lastName = 'نام خانوادگی باید حداقل 3 کاراکتر باشد.';
  } else if (!/^[\u0600-\u06FF\s]+$/.test(lastName)) {
    errors.lastName = 'نام خانوادگی باید فقط شامل حروف فارسی باشد.';
  }

  if (!postalCode) {
    errors.postalCode = 'کد پستی الزامی است.';
  } else if (!/^\d{10}$/.test(postalCode)) {
    errors.postalCode = 'کد پستی باید 10 رقم باشد.';
  }

  if (!address) {
    errors.address = 'آدرس الزامی است.';
  } else if (address.length < 10) {
    errors.address = 'آدرس باید حداقل 10 کاراکتر باشد.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}