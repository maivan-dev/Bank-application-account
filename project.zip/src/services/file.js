export function base64ToFile(base64Data, fileName, mimeType) {
  let byteString = atob(base64Data.split(',')[1])
  let ab = new ArrayBuffer(byteString.length)
  let ia = new Uint8Array(ab)
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i)
  }
  return new File([ab], fileName, { type: mimeType })
}
