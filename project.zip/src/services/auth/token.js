export const setLoginToken = (token, expiresIn) => {
  document.cookie = `loginToken=${token}; max-age=${expiresIn}; path=/;`
}

export const getLoginToken = () => {
  const name = 'loginToken='
  const decodedCookies = decodeURIComponent(document.cookie)
  const cookiesArray = decodedCookies.split(';')

  for (let cookie of cookiesArray) {
    cookie = cookie.trim()
    if (cookie.startsWith(name)) {
      return cookie.substring(name.length, cookie.length)
    }
  }
  return false
}

export const removeLoginToken = () => {
  document.cookie = 'loginToken=; max-age=0; path=/;'
}
