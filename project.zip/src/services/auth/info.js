export const setUserData = (firstName, lastName, phoneNumber) => {
  localStorage.setItem('userFirstName', firstName)
  localStorage.setItem('userLastName', lastName)
  localStorage.setItem('userPhoneNumber', phoneNumber)
}

export const getUserData = () => {
  const firstName = localStorage.getItem('userFirstName')
  const lastName = localStorage.getItem('userLastName')
  const phoneNumber = localStorage.getItem('userPhoneNumber')

  return {
    firstName,
    lastName,
    phoneNumber,
  }
}
