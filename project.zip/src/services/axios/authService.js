import { faToEnDigits } from '@/utilities/numberFunctions'
import api from './api'
import { getLoginToken } from '../auth/token'

export const login = (phoneNumber, password) => {
  return api.post('/auth/login', {
    phoneNumber: faToEnDigits(phoneNumber),
    password: faToEnDigits(password),
  })
}

export const logout = () => {
  return api.post(
    '/auth/logout',
    {},
    {
      headers: {
        Authorization: `Bearer ${getLoginToken()}`,
      },
    },
  )
}

export const checkLogin = () => {
  return api.get('/deposit-account', {
    headers: {
      Authorization: `Bearer ${getLoginToken()}`,
    },
  })
}

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = '/login'
    }
    return Promise.reject(error)
  },
)
