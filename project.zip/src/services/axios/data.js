import { getLoginToken } from '../auth/token'
import api from './api'
import apiFormData from './apiFormData'

export const getUserInfo = async () => {
  return api.get('/deposit-account', {
    headers: {
      Authorization: `Bearer ${getLoginToken()}`,
    },
  })
}

export const getTransactions = async (type, page) => {
  return api.get(`/transactions?page=${page}&pageSize=5${type !== '' ? `&type=${type}` : ''}`, {
    headers: {
      Authorization: `Bearer ${getLoginToken()}`,
    },
  })
}

export const createAccount = async (formData) => {
  return apiFormData.post(`/deposit-account`, formData, {
    headers: {
      Authorization: `Bearer ${getLoginToken()}`,
    },
  })
}

export const deleteAccount = async () => {
  return apiFormData.delete(`/deposit-account`, {
    headers: {
      Authorization: `Bearer ${getLoginToken()}`,
    },
    data: {
      accountId: '',
    },
  })
}
