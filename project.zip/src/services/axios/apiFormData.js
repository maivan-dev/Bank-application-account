import axios from 'axios'

const apiFormData = axios.create({
  baseURL: '/api',
  withCredentials: true,
})

export default apiFormData
