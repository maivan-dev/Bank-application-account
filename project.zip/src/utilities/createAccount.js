export function checkStep() {
  const firstName = localStorage.getItem('firstName')
  const lastName = localStorage.getItem('lastName')
  const postalCode = localStorage.getItem('postalCode')
  const address = localStorage.getItem('address')

  const nationalCard = localStorage.getItem('nationalCard')
  const backNationalCard = localStorage.getItem('backNationalCard')

  let step = 1
  if (
    firstName?.length > 0 &&
    lastName?.length > 0 &&
    postalCode?.length > 0 &&
    address?.length > 0
  ) {
    step = 2
    if (nationalCard?.length > 0 && backNationalCard?.length > 0) {
      step = 3
    }
  }
  return step
}
