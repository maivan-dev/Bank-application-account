export function moneySeperateDigits(str) {
  if (!(typeof str === 'string' || typeof str === 'number')) return false
  str = String(str)
  let result = ''
  if (!str || str?.length === 0) {
    return '0'
  }
  let mod = str.length % 3
  for (let index = 0; index < str.length; index++) {
    if (index % 3 === mod && index !== 0) {
      result += '’'
    }
    result += str[index]
  }
  return result
}

export function brakingCardNumber(cardNumber) {
  if (typeof cardNumber === 'string' && cardNumber?.length === 16) {
    return [
      cardNumber.slice(0, 4),
      cardNumber.slice(4, 8),
      cardNumber.slice(8, 12),
      cardNumber.slice(12, 16),
    ]
  } else return []
}

export const faToEnDigits = (str) => {
  if (typeof str !== 'string' && !(str instanceof String)) return false
  return str.toString().replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
}

export const dateSeperated = (date) => {
  if ((typeof date !== 'string' && !(date instanceof String)) || date === '' || date === '-') {
    return false
  }
  return date?.slice(0, 4) + '/' + date?.slice(4, 6) + '/' + date?.slice(6, 8)
}
