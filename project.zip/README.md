# Final Project - Banking Dashboard Application

A modern Vue.js 3 application for banking and financial services with Persian/Farsi language support. This application provides a comprehensive dashboard for managing bank accounts, viewing transactions, and handling account operations.

## 🚀 Features

### Authentication & Security

- User login with phone number and password
- JWT token-based authentication
- Protected routes with automatic redirects
- Session management with token expiration

### Dashboard Features

- **Account Overview**: View account balance, card number, and account details
- **Account Points**: Display and calculate account points system
- **Installment Management**: View upcoming installments and payment details
- **Transaction History**: Paginated transaction table with filtering
- **Account Management**: Create and delete deposit accounts

### Account Creation Process

- Multi-step account creation workflow
- Personal information collection
- National card upload and verification
- Account confirmation process

### UI/UX Features

- Responsive design with modern UI components
- Persian/Farsi language support with RTL layout
- Loading states and toast notifications
- Modal dialogs for user interactions
- Custom SVG icons and components

## 🛠️ Tech Stack

### Frontend

- **Vue 3** - Progressive JavaScript framework
- **Vue Router 4** - Client-side routing
- **Pinia** - State management
- **Vite** - Build tool and development server
- **SCSS** - CSS preprocessor with custom styling

### Development Tools

- **ESLint** - Code linting and formatting
- **Prettier** - Code formatting
- **Vue DevTools** - Development debugging
- **Axios** - HTTP client for API requests

### Styling & Assets

- Custom Persian fonts (Peyda family)
- Responsive design with SCSS
- SVG icons and custom components
- Background images and graphics

## 📁 Project Structure

```
src/
├── components/           # Reusable Vue components
│   ├── create-account/   # Account creation components
│   ├── dashboard/        # Dashboard-specific components
│   ├── header/           # Header components
│   ├── login/            # Login form components
│   ├── svg/              # SVG components
│   ├── svgIcons/         # Icon components
│   └── toast/            # Notification components
├── services/             # API services and utilities
│   ├── auth/             # Authentication services
│   ├── axios/            # HTTP client configuration
│   └── validations/      # Form validation utilities
├── stores/               # Pinia state management
├── utilities/            # Helper functions
├── views/                # Page components
└── router/               # Vue Router configuration
```

## 🚀 Getting Started

### Prerequisites

- Node.js (version 20.19.0 or >=22.12.0)
- npm or yarn package manager

### Installation

1. **Clone the repository**

   ```bash
   git clone <repository-url>
   cd FinalProject
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Start development server**

   ```bash
   npm run dev
   ```

4. **Build for production**

   ```bash
   npm run build
   ```

5. **Preview production build**
   ```bash
   npm run preview
   ```

### Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build application for production
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint with auto-fix
- `npm run format` - Format code with Prettier

## 🔧 Configuration

### API Configuration

The application is configured to proxy API requests to `https://turbofront5.onrender.com`. API configuration can be found in:

- `vite.config.js` - Proxy settings for development
- `src/services/axios/api.js` - Base API configuration

### Environment Variables

Create a `.env` file in the root directory if needed:

```env
VITE_API_BASE_URL=your_api_base_url
```

## 🎨 Styling & Theming

The application uses SCSS with a custom design system:

- **Variables**: `src/assets/styles/abstracts/_variables.scss`
- **Mixins**: `src/assets/styles/abstracts/_mixins.scss`
- **Main Styles**: `src/assets/styles/main.scss`

### Font Support

- **Peyda Family**: Custom Persian font family
- **IRANSansX**: Persian number support
- RTL (Right-to-Left) text direction support

## 🔐 Authentication Flow

1. **Login**: Users authenticate with phone number and password
2. **Token Storage**: JWT tokens are stored and managed automatically
3. **Route Protection**: Protected routes redirect to login if not authenticated
4. **Session Management**: Automatic token refresh and logout on expiration

## 📱 Pages & Routes

- `/` - Home page with navigation links
- `/login` - User authentication
- `/dashboard` - Main dashboard (protected)
- `/create-account/personal-info` - Personal information form
- `/create-account/national-card` - National card upload
- `/create-account/confirm-information` - Account confirmation
- `/*` - 404 Not Found page

## 🔄 State Management

The application uses Pinia for state management with the following stores:

- `dashboardStore.js` - Dashboard data and UI state
- `tableStore.js` - Transaction table state
- `loader.js` - Global loading state
- `counter.js` - General counter state

## 🚦 API Integration

### Authentication Endpoints

- `POST /auth/login` - User login
- `POST /auth/logout` - User logout

### Data Endpoints

- `GET /deposit-account` - Get user account information
- `POST /deposit-account` - Create new account
- `DELETE /deposit-account` - Delete account
- `GET /transactions` - Get transaction history

## 🎯 Key Components

### Dashboard Components

- `BankCard` - Account balance and card information
- `InstallmentCard` - Installment and points display
- `TableTransactions` - Transaction history table
- `SidebarDashboard` - Navigation sidebar

### Form Components

- `PhoneInput` - Persian phone number input
- `PasswordInput` - Password input with validation
- `UploadBox` - File upload component
- `InputBase` - Base input component

## 🌐 Internationalization

The application supports Persian/Farsi language with:

- Persian text content
- RTL layout support
- Persian number formatting
- Custom Persian fonts

## 🛡️ Security Features

- JWT token authentication
- Protected routes
- Input validation and sanitization
- CORS configuration
- Secure API communication

## 📊 Performance

- Lazy-loaded routes for better performance
- Component-based architecture
- Optimized bundle with Vite
- Efficient state management with Pinia

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is private and proprietary.

## 📞 Support

For support and questions, please contact the development team.

---

**Note**: This application is designed for Persian/Farsi users and includes RTL support, custom Persian fonts, and localized content.
